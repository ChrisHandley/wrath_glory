keywords_aeldari = [
    {'label': 'None', 'value': 'None'},
]

keywords_aeldari_sub={
    'Anhrathe': [
        {'label': 'Coterie', 'value': 'Coterie'},
        {'label': 'Psyker', 'value': 'Psyker'},
    ],
    'Asuryani': [
        {'label': 'Aspect Warrior', 'value': 'Aspect Warrior'},
        {'label': 'Craftworld', 'value': 'Coterie'},
        {'label': 'Psyker', 'value': 'Psyker'},
    ],
    'Drukhari': [
        {'label': 'Coven', 'value': 'Coven'},
        {'label': 'Blades For Hire', 'value': 'Blades For Hire'},
        {'label': 'Kabal', 'value': 'Kabal'},
        {'label': 'Wych Cult', 'value': 'Wych Cult'},
    ],
    'Harlequin': [
        {'label': 'Masque', 'value': 'Masque'},
        {'label': 'Psyker', 'value': 'Psyker'},
    ],
    'Ynnari': [
        {'label': 'None', 'value': 'None'},
    ]
}

keywords_drukhari = [
    {'label': 'None', 'value': 'None'},
]

keywords_drukhari_sub={
    'Anhrathe': [
        {'label': 'Coterie', 'value': 'Coterie'},
        {'label': 'Psyker', 'value': 'Psyker'},
    ],
    'Drukhari': [
        {'label': 'Coven', 'value': 'Coven'},
        {'label': 'Blades For Hire', 'value': 'Blades For Hire'},
        {'label': 'Kabal', 'value': 'Kabal'},
        {'label': 'Wych Cult', 'value': 'Wych Cult'},
    ],
    # 'Harlequin': [
    #     {'label': 'Masque', 'value': 'Masque'},
    #     {'label': 'Psyker', 'value': 'Psyker'},
    # ],
    'Ynnari': [
        {'label': 'None', 'value': 'None'},
    ]
}