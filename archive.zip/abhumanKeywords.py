keywords_abhumans_imperial=[
    {'label': 'Astra Militarum', 'value': 'Astra Militarum'},
    {'label': 'Unaligned', 'value': 'Unaligned'}
]

keywords_abhumans_imperial_sub={
    'Astra Militarum': [
        {'label': 'Militarum Auxilla', 'value': 'Militarum Auxilla'},
        {'label': 'Regiment', 'value': 'Regiment'}
    ],
    'Unaligned': [
        {'label': 'Mutant', 'value': 'Mutant'},
        {'label': 'Scum', 'value': 'Scum'}
    ],
}

keywords_abhumans_chaos=[

    {'label': 'Unaligned', 'value': 'Unaligned'}
]

keywords_abhumans_chaos_sub={
    'Unaligned': [
        {'label': 'Chaos', 'value': 'Chaos'},
        {'label': 'Chaos Undivided', 'value': 'Chaos Undivided'},
        {'label': 'Khorne', 'value': 'Khorne'},
        {'label': 'Nurgle', 'value': 'Nurgle'},
        {'label': 'Slaanesh', 'value': 'Slaanesh'},
        {'label': 'Tzeentch', 'value': 'Tzeentch'}
    ],
}