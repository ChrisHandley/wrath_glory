keywords_astartes_imperial=[
    {'label': 'None', 'value': 'None'},
]

keywords_astartes_imperial_sub=[
    {'label': 'None', 'value': 'None'},
    {'label': 'Psyker', 'value': 'Psyker'},
    {'label': 'Adeptus Ministorum', 'value': 'Adeptus Ministorum'},
]

keywords_primaris_imperial=[
    {'label': 'None', 'value': 'None'},
]

keywords_primaris_imperial_sub=[
    {'label': 'None', 'value': 'None'},
    {'label': 'Psyker', 'value': 'Psyker'},
    {'label': 'Adeptus Ministorum', 'value': 'Adeptus Ministorum'},
]

keywords_astartes_chaos=[
    {'label': 'None', 'value': 'None'},
]

keywords_astartes_chaos_sub=[
    {'label': 'Heretic Astartes, Legion', 'value': 'Heretic Astartes'},
    {'label': 'Psyker', 'value': 'Psyker'},
    {'label': 'Chaos', 'value': 'Chaos'},
    {'label': 'Chaos Undivided', 'value': 'Chaos Undivided'},
    {'label': 'Khorne', 'value': 'Khorne'},
    {'label': 'Nurgle', 'value': 'Nurgle'},
    {'label': 'Slaanesh', 'value': 'Slaanesh'},
    {'label': 'Tzeentch', 'value': 'Tzeentch'}
]
